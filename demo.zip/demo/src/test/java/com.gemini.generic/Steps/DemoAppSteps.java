package com.gemini.generic.Steps;

import com.gemini.generic.MobileAction;
import com.gemini.generic.UIPage.Locators;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.core.pages.PageObject;

public class DemoAppSteps extends PageObject {

    @Given("Launch the Application")
    public void launchApplication(){System.out.println("Application launched");}

    @When("Login")
    public void Login() {
        typeInto(MobileAction.getElement(Locators.name),"Test1");
        MobileAction.takeSnapShot();
        clickOn(MobileAction.getElement(Locators.LetsShopBtn));
        System.out.println("Login successful");

//        MobileAction.typeText(com.gemini.generic.UiPage.Locators.name, "ABC", "Enter Username");
//        MobileAction.waitSec(1);
//        MobileAction.click(com.gemini.generic.UiPage.Locators.countryDropdown, "open country select dropdown");
//        MobileAction.waitSec(1);
//        MobileAction.click(com.gemini.generic.UiPage.Locators.countrySelect, "Select Angola");
//        MobileAction.waitSec(1);
//        MobileAction.click(com.gemini.generic.UiPage.Locators.female, "Select gender Female");
//        MobileAction.click(com.gemini.generic.UiPage.Locators.btnLogin, "Click Submit");
    }

    @Then("Add to Cart")
    public void AddtoCart()
    {
        clickOn(MobileAction.getElement((Locators.AddtoCartoption)));
        MobileAction.takeSnapShot();
//        if(MobileAction.getTitle().equalsIgnoreCase("Products"))
//            System.out.println("Login Successful");
//        else
//            System.out.println("Fail");

        clickOn(MobileAction.getElement((Locators.CartBtn)));
        MobileAction.takeSnapShot();

        clickOn(MobileAction.getElement((Locators.CartBtn)));
        MobileAction.takeSnapShot();

        System.out.println("Order placed");
    }


//    public void openJordanRetro() {
//        MobileAction.scrollToElement("Air Jordan 4 Retro", true);
//    }
//    public void Add_item_to_cart(){
//        MobileAction.click(com.gemini.generic.UIPage.Locators.productsAddtoCart,"Add to Cart");
//        MobileAction.waitSec(2);
//        MobileAction.click(com.gemini.generic.UIPage.Locators.CartBtn,"Open Cart");
//        MobileAction.waitSec(2);
//    }
//
//    public void Validate_itemInCart(){
//        if(MobileAction.getElementText(com.gemini.generic.UIPage.Locators.productCart).contains("Air"))
//            System.out.println("Successfully added to cart");
//        else
//            System.out.println("Failed");
//    }
    public void Website(){
        MobileAction.click(com.gemini.generic.UIPage.Locators.Proceed,"Visit Website");
    }
}
