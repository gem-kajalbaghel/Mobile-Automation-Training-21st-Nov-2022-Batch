package com.gemini.generic.UIPage;

import io.appium.java_client.AppiumBy;
import org.apache.commons.compress.harmony.pack200.PackingUtils;
import org.openqa.selenium.By;

public class Locators
{
    public static By name = AppiumBy.id("com.androidsample.generalstore:id/nameField");
    public static By country = AppiumBy.id("com.androidsample.generalstore:id/spinnerCountry");
    public static By SelectCountry= AppiumBy.xpath("//android.widget.TextView");
    public static By male = AppiumBy.id("com.androidsample.generalstore:id/radioMale");
    public static By female = AppiumBy.id("com.androidsample.generalstore:id/radioFemale");
    public static By LetsShopBtn = AppiumBy.id("com.androidsample.generalstore:id/btnLetsShop");
    public static By BackBtn = AppiumBy.id("com.androidsample.generalstore:id/appbar_btn_cart");
    public static By productCart= AppiumBy.id("com.androidsample.generalstore:id/productName");
    public static By AddtoCartoption= AppiumBy.xpath("(//android.widget.TextView)[4]");
    public static By CartBtn = AppiumBy.id("com.androidsample.generalstore:id/appbar_btn_cart");
//    public static By emaildiscounts= AppiumBy.xpath("//android.widget.CheckBox");
//    public static By image= AppiumBy.id("hplogo");
    public static By Proceed= AppiumBy.id("com.androidsample.generalstore:id/btnProceed");

}
