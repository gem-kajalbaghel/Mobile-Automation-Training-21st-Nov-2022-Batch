package Steps;

import UIPage.DemoAppPage;
import net.thucydides.core.annotations.Step;

public class DemoAppSteps  {

    DemoAppPage demoAppPageSteps;

    @Step("^Click on Preference$")
    public void preference(){
        demoAppPageSteps.selectPreference();
        demoAppPageSteps.selectPreferenceDependencies();
        demoAppPageSteps.selectWifiCheckBox();
        demoAppPageSteps.selectWifiSettings();
        demoAppPageSteps.enterWifiName("Some_Random_Wifi");
        demoAppPageSteps.clickOkButton();
    }

    @Step("^Long Press Feature Check")
    public void LongPressFeatureStep(){
        demoAppPageSteps.LongPressFeature();
        System.out.println("Long Press Feature Performed");
    }
    @Step("^Click on Alert PopUp$")
    public void clickOnAlertPopUpStep(){
        demoAppPageSteps.clickOnAlertPopUp();
        System.out.println("Click on Alert Feature Performed");
    }

    @Step("^Scroll Feature Steps$")
    public void scrollFeatureSteps(){
        demoAppPageSteps.scrollFeature();
    }

    @Step("^Swipe Feature Steps$")
    public void swipeFeatureSteps(){
        demoAppPageSteps.swipeFeature();
    }

    @Step("^Drop Down And Get List Feature Step$")
    public void dropDownAndGetListFeatureStep(){
        demoAppPageSteps.dropDownAndGetListFeature();
    }
    @Step("^DropDown Toast Message Assertion Step$")
    public void dropDownToastMessageAssertionStep(){
        demoAppPageSteps.dropDownToastMessageAssertion();
    }
    @Step("^Drag And Drop Assertion Step$")
    public void dragAndDropAssertionStep(){
        demoAppPageSteps.dragAndDropAssertion();
    }
    @Step("^Closing the Application$")
    public void closeApp(){
        System.out.println("Application Closing");
    }
}
