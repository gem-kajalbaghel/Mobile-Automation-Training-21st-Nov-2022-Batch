package UIPage;

import com.google.common.collect.ImmutableMap;
import groovy.transform.Immutable;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.cucumber.java.sl.In;
import jdk.jfr.Threshold;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.webdriver.WebDriverFacade;
import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.devtools.v85.input.model.TouchPoint;
import org.openqa.selenium.remote.RemoteWebElement;

import java.util.List;

import static java.time.Duration.ofSeconds;


public class DemoAppPage extends PageObject {

    AndroidDriver driver =(AndroidDriver) ((WebDriverFacade) getDriver()).getProxiedDriver();

    public void selectPreference(){
//        clickOn(element(Locators.option_preference));//PageObject method
        $(Locators.option_preference).click();
    }
    public void selectPreferenceDependencies(){
        $(Locators.optionPreference_dependencies).click();// WebElementFacade method
    }
    public void selectWifiCheckBox(){
        $(Locators.checkbox_wifi).click();// WebElementFacade method
    }
    public void selectWifiSettings(){

        clickOn(element(Locators.option_wifiSettings));//PageObject method
    }
    public void enterWifiName(String wifiName){
//        $(Locators.input_wifiName).sendKeys(wifiName);
        typeInto(element(Locators.input_wifiName),wifiName);//PageObject method
    }
    public void clickOkButton(){
        clickOn(element(Locators.alert_OkButton));//PageObject method

        System.out.println("Test Completed!!!");
    }

    public void LongPressFeature(){
        clickOn(element(Locators.option_views));
        clickOn(element(Locators.optionViews_expandableList));
        clickOn(element(Locators.optionExpandableList_CustomAdapter));

        LongPressOptions longPressOptions = new LongPressOptions();

        WebElement peopleNames = driver.findElement(Locators.optionCustomAdapter_PeopleNames);

        longPressOptions.withDuration(ofSeconds(2)).withElement(ElementOption.element(peopleNames));

        TouchAction action = new TouchAction((PerformsTouchActions) driver);

        action.longPress(longPressOptions).perform().release();
        System.out.println("Long Press Feature Executed Successfully");

    }

    public void clickOnAlertPopUp(){
        clickOn(element(Locators.option_app));
        clickOn(element(Locators.optionApp_AlertDialogs));
        clickOn(element(Locators.optionAlertDialogs_OkCancelAlert));
        clickOn(element(Locators.alertOk));
        System.out.printf("Click on Alert Feature Executed Successfully");
    }

    public void scrollFeature() {
        Boolean isPassed = Boolean.FALSE;
        // Scroll Down to WebView

        try{
            clickOn(element(Locators.option_views));
            driver.findElement(AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView"+"(text(\"WebView\"));"));
            isPassed = Boolean.TRUE;
            Thread.sleep(2000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }
        // Scroll up to Gallery
//        driver.findElement(AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView"+"(text(\"Gallery\"));"));
        if(isPassed == Boolean.TRUE)
            System.out.println("Scroll Feature Executed Successfully");
        else
            System.out.println("Scrolling Not Executed");

    }

    public void swipeFeature()  {

        clickOn(element(Locators.option_views));
        clickOn(element(Locators.gallery));
        clickOn(element(Locators.photos));

        WebElement img1 = driver.findElement(AppiumBy.xpath("(//android.widget.ImageView)[1]"));
        WebElement img3 = driver.findElement(AppiumBy.xpath("(//android.widget.ImageView)[3]"));

        // Direction can be Up , Left , Down , Right
        ((JavascriptExecutor) driver).executeScript("mobile: swipeGesture", ImmutableMap.of(
           "elementId", ((RemoteWebElement) img1).getId(),
           "direction","left",
           "percent",1
        ));

        System.out.println("Swipe Feature executed Successfully");
    }

    public void dropDownAndGetListFeature(){
        clickOn(element(Locators.option_views));

        driver.findElement(AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView"+"(text(\"Popup Menu\"));")).click();
        clickOn(element(Locators.makeAPopup));
        List<WebElement> elements = driver.findElements(AppiumBy.xpath("//android.widget.TextView"));

        for ( WebElement element : elements){
            System.out.println("Element is clicked!!!==="+element.getText());
            clickOn(element);
            try{
                Thread.sleep(3000);
            }catch (Exception e){
                e.printStackTrace();
            }
            break;
        }
        System.out.println("Drop Down list Feature executed Successfully");
    }

    public void dropDownToastMessageAssertion() {
        try {
            clickOn(element(Locators.option_views));


        driver.findElement(AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView" + "(text(\"Popup Menu\"));")).click();
        clickOn(element(Locators.makeAPopup));
        List<WebElement> elements = driver.findElements(AppiumBy.xpath("//android.widget.TextView"));

        clickOn(elements.get(0)); // Clicking on Search Item from list
        String toastMessage = element(Locators.ToastMessage).getAttribute("name");
        System.out.println("Toast Message ===" + toastMessage);
        Assert.assertEquals(toastMessage, "Clicked popup menu item Search");
        System.out.println("Drop Down list Feature executed Successfully");
    }
    catch  (Exception e){
            e.printStackTrace();
    }
    }

    public void dragAndDropAssertion(){
        try{
            clickOn(element(Locators.option_views));
            clickOn(element(Locators.option_DragAndDrop));
            WebElement dragFileOrObject = driver.findElement(AppiumBy.id("io.appium.android.apis:id/drag_dot_1"));
            ((JavascriptExecutor) driver).executeScript("mobile: dragGesture",ImmutableMap.of(
                    "elementId",((RemoteWebElement) dragFileOrObject).getId(),
                    "endX",515,
                    "endY",781
            ));
            String msg = driver.findElement(AppiumBy.id("io.appium.android.apis:id/drag_result_text")).getAttribute("name");
            System.out.println("Toast Message ==="+msg);
            Assert.assertEquals(msg,"Dropped!");
            System.out.println("Drag and Drop Assertion executed Successfully");
        }catch (Exception e){
            e.printStackTrace();
        }

    }
}

