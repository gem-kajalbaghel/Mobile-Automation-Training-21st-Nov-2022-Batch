package com.gemini.generic.Locators;

import io.appium.java_client.AppiumBy;
import org.openqa.selenium.By;

import java.util.ArrayList;
import java.util.List;

public class Locators {

    public static By img = AppiumBy.id("hplogo");
    public static By name = AppiumBy.id("com.androidsample.generalstore:id/nameField");

    public static By radio_Male = AppiumBy.id("com.androidsample.generalstore:id/radioMale");
    public static By LetsShop = AppiumBy.id("com.androidsample.generalstore:id/btnLetsShop");
    public static By countryOtions = AppiumBy.id("com.androidsample.generalstore:id/spinnerCountry");
    public static By country_Name=AppiumBy.xpath("//android.widget.TextView[@text='Canada']");

    public static By product_Name=  AppiumBy.id("com.androidsample.generalstore:id/productName");
    public static By Add_to_Cart= AppiumBy.id("com.androidsample.generalstore:id/productAddCart");
    public static By btn =AppiumBy.id("com.androidsample.generalstore:id/appbar_btn_cart");

    //    public static By terms_Button=AppiumBy.id("com.androidsample.generalstore:id/termsButton");
//    public static By accept_Button= AppiumBy.id("android:id/button1"); accept the terms and policy
    public static By visit_Website=AppiumBy.id("com.androidsample.generalstore:id/btnProceed");

    public static By googleSearch=By.name("q");
}
