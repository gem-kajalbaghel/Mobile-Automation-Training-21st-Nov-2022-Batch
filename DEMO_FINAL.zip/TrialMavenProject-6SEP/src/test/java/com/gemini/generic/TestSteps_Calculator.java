package com.gemini.generic;


import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.io.IOException;

public class TestSteps_Calculator {

    @Given("Click the desired numbers")
            public void Click_the_desired_numbers() throws IOException {
        MobileAction.click(Locators.seven);
    }
    @When("Click on the addition button")
            public void Click_on_the_addition_button(){
        MobileAction.click(Locators.add_Button);
        MobileAction.click(Locators.three);
    }
     @Then("Perform addition")
    public void Perform_addition(){
        MobileAction.click(Locators.equals_Button);
        MobileAction.pressBackButton();

     }

     @Given("Click on three button")
    public void Click_on_three_button(){
        MobileAction.click(Locators.three);
     }

     @Then("Press Home Button")
    public void Press_Home_Button(){
        MobileAction.pressHomeButton();
     }

}
