package Steps;

import Locators.Locator;
import com.gemini.generic.MobileAction;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;

import java.util.Locale;


public class StepDefinition {


    @Step
    @Given("Launch Application")
    public void launch_application() {
        System.out.println("Application Launched Successfully");
    }
    @Step
    @When("Mention all Details and Enter into Application")
    public void mention_all_details_and_enter_into_application() {
        MobileAction.takeSnapShot();
        MobileAction.typeText(Locator.enterYourName,"Hello");
        MobileAction.takeSnapShot();
        MobileAction.click(Locator.letsShopButton);
        MobileAction.takeSnapShot();

        System.out.println("Primary Details Entered");
    }
    @Step
    @Then("Order First Item")
    public void order_first_item() {
        MobileAction.takeSnapShot();

        MobileAction.click(Locator.addToCart_option);
        MobileAction.takeSnapShot();

        MobileAction.click(Locator.cartButton);
        MobileAction.takeSnapShot();
        MobileAction.click(Locator.sendEmailOnDiscounts_CheckBox);
        MobileAction.takeSnapShot();
        MobileAction.click(Locator.letsProceedForPurchase);
        MobileAction.takeSnapShot();

        System.out.println("Order Placed Successfully!!!");
    }

}
