package StepDefinitions;

import Steps.DemoAppSteps;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;


public class DemoAppTest {

    @Steps
    DemoAppSteps demotest;

        @Given("open the wifi settings")
        public void openTheWifiSettings() {
        demotest.preference();
        }

        @When("enter the name as {string}")
        public void enterTheNameAs(String name) {
         demotest.wifiname();

        }

        @Then("close the application")
        public void closeTheApplication() {
            demotest.closeApp();
        }

    @Given("Click on the views")
    public void clickOnTheViews() {
        System.out.println("views clicked");
    }

    @When("Click on expandable list")
    public void clickOnExpandableList() {
        System.out.println("Expandable list clicked");
    }

    @When("Click on custom adapter")
    public void clickOnCustomAdapter() {
        System.out.println(" Custom adapter click");
    }

    @When("Longpress on people name")
    public void longpressOnPeopleName() {
        demotest.longpress();
    }

}


