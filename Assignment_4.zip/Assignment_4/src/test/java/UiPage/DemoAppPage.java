package UiPage;

import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.offset.ElementOption;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.webdriver.WebDriverFacade;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;


import static java.time.Duration.ofSeconds;

public class DemoAppPage extends PageObject {
    AndroidDriver driver = (AndroidDriver) ((WebDriverFacade) getDriver()).getProxiedDriver();

    public void clickonperfernce(){
        clickOn(element(Locators.option_preference));
    }

    public void clickonprefdependencies(){
        clickOn(element(Locators.option_prefDependencies));
    }

    public void clickonWificheckbox(){
        clickOn(element(Locators.checkBox_Wifi));
    }

    public void enterWifiname(String name){
        clickOn(element(Locators.option_wifiSettings));
        typeInto(element(Locators.input_wifiName), name);
    }

    public void clickOkButton() {

        clickOn(findAll(Locators.alert_buttons).get(1));
    }

    public void doClick(By locator) {
        clickOn(element(locator));
    }

    public void closeApplication() {

        try {
            Thread.sleep(2000);
            System.out.println("app closed!");
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public void doLongPress(By locator) {
        LongPressOptions longPressOptions = new LongPressOptions();
        WebElement element = getAndroidDriver().findElement(locator);
        longPressOptions.withDuration(ofSeconds(2)).withElement(ElementOption.element(element));
        TouchAction action = new TouchAction((PerformsTouchActions) getAndroidDriver());
        action.longPress(longPressOptions).release().perform();
    }
    public AndroidDriver getAndroidDriver(){
        return (AndroidDriver) ((WebDriverFacade) getDriver()).getProxiedDriver();
    }


}
