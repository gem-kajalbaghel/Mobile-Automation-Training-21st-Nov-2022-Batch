package Steps;

import UiPage.DemoAppPage;
import UiPage.Locators;
import net.thucydides.core.annotations.Step;

public class DemoAppSteps {
    DemoAppPage demosteps;

    @Step("^Click on Preference$")
        public void preference(){
        demosteps.clickonperfernce();
        demosteps.clickonprefdependencies();
        demosteps.clickonWificheckbox();
//        demosteps.enterWifiname("Shruti");
    }

    @Step("^Enter wifi name$")
    public void wifiname(){
     demosteps.enterWifiname("Shruti");
     demosteps.clickOkButton();
    }

    @Step("^To check for long press")
    public void longpress(){
        demosteps.doClick(Locators.views);
        demosteps.doClick(Locators.expandableList);
        demosteps.doClick(Locators.customAdapter);
        demosteps.doLongPress(Locators.peopleName);

    }

    @Step("^Close the app$")
    public void closeApp(){
        demosteps.closeApplication();
    }


}
