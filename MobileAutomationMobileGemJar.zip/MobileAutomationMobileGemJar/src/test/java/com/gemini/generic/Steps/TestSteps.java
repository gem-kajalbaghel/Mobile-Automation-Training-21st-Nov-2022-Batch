package com.gemini.generic.Steps;

import com.gemini.generic.Locators.Locators;
import com.gemini.generic.MobileAction;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;

import java.util.Locale;

public class TestSteps extends PageObject {

    @Step
    @Given("Launch Application")
    public void launchApplication(){
        System.out.println("Application Launched Successfully");
    }

    @When("Mention all Details and Enter into Application")
    public void insertDetails(){
        MobileAction.takeSnapShot();
        MobileAction.typeText(Locators.enterYourName,"Hello");
        MobileAction.takeSnapShot();
        MobileAction.click(Locators.letsShopButton);
        MobileAction.takeSnapShot();

        System.out.println("Primary Details Entered");
//        MobileAction.waitUntilElementVisible();

    }

    @Then("Order First Item")
    public void orderFirstItem(){
        MobileAction.takeSnapShot();

        MobileAction.click(Locators.addToCart_option);
        MobileAction.takeSnapShot();

        MobileAction.click(Locators.cartButton);
        MobileAction.takeSnapShot();
        MobileAction.click(Locators.sendEmailOnDiscounts_CheckBox);
        MobileAction.takeSnapShot();
        MobileAction.click(Locators.letsProceedForPurchase);
        MobileAction.takeSnapShot();

        System.out.println("Order Placed Successfully!!!");
    }
}
