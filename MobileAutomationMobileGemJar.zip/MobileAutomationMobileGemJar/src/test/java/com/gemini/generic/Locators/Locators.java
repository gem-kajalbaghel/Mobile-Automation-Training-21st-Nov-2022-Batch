package com.gemini.generic.Locators;

import io.appium.java_client.AppiumBy;
import org.openqa.selenium.By;

import java.util.ArrayList;
import java.util.List;

public class Locators {
    public static By spinnerCountry = AppiumBy.id("com.androidsample.generalstore:id/spinnerCountry");
    public static By selectCountry = AppiumBy.xpath("//android.widget.TextView");
    public static By enterYourName = AppiumBy.id("com.androidsample.generalstore:id/nameField");
    public static By genderRadioMale = AppiumBy.id("com.androidsample.generalstore:id/radioMale");
    public static By genderRadioFemale = AppiumBy.id("com.androidsample.generalstore:id/radioFemale");
    public static By letsShopButton = AppiumBy.id("com.androidsample.generalstore:id/btnLetsShop");
    public static By backButton = AppiumBy.id("com.androidsample.generalstore:id/appbar_btn_back");
    public static By addToCart_option = AppiumBy.xpath("(//android.widget.TextView)[4]");
    public static By cartButton = AppiumBy.id("com.androidsample.generalstore:id/appbar_btn_cart");
    public static By sendEmailOnDiscounts_CheckBox = AppiumBy.xpath("//android.widget.CheckBox");
    public static By letsProceedForPurchase = AppiumBy.id("com.androidsample.generalstore:id/btnProceed");
    public static By img = AppiumBy.id("hplogo");
}
