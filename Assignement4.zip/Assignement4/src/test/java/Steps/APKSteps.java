package Steps;

import UIPage.DemoAppPage;
import net.thucydides.core.annotations.Step;

public class APKSteps {

    DemoAppPage demoAppPage ;


@Step("^Click on Preferences$")
    public void preferences(){
    demoAppPage.selectPreference();
    demoAppPage.selectPreferenceDependencies();
    demoAppPage.selectWifiCheckBox();
    demoAppPage.selectWifiSettings();
    demoAppPage.enterWifiName("sandeep");
    demoAppPage.clickOkButton();
}

@Step("^Enter name of wifi$")
    public void enterWifiName(){
    demoAppPage.enterWifiName("sandeep");
    demoAppPage.clickOkButton();
}
@Step("^Close the application$")
    public void closeApplication(){
    System.out.println("test ended");
}
    @Step("^Long Press Feature Check")
    public void LongPressFeatureStep(){
        demoAppPage.LongPressFeature();
        System.out.println("Long Press Feature Performed");
    }
    @Step("^Closing the Application$")
    public void closeApp(){
        System.out.println("Application Closing");
    }
}
