package com.gemini.generic;


import io.cucumber.java.en.Given;

import java.io.IOException;

public class TestSteps_Calculator {
//    driver.findElement(AppiumBy.id("com.bak.mnr.calculatrice:id/btn7")).click();
//        driver.findElement(AppiumBy.id("com.bak.mnr.calculatrice:id/btnP")).click();
//        driver.findElement(AppiumBy.id("com.bak.mnr.calculatrice:id/btn3")).click();
//        driver.findElement(AppiumBy.id("com.bak.mnr.calculatrice:id/btnE")).click();
    @Given("Click the desired numbers")
            public void Click_the_desired_numbers() throws IOException {
        MobileAction.click(Locators.seven);
        MobileAction.click(Locators.add_Button);
        MobileAction.click(Locators.three);
    }


}
