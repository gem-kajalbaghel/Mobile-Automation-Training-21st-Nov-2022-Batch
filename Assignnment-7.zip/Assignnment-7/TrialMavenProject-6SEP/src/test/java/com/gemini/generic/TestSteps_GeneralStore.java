package com.gemini.generic;


import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.cucumber.java.en.*;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;


import java.io.IOException;
import java.util.Set;

public class TestSteps_GeneralStore {

    @Given("Login to the app")
    public void login_to_the_app() throws IOException {


        MobileAction.setImplicitTimeOut(6);


        MobileAction.typeText(Locators.input_Name, "Test", "name");
        MobileAction.waitSec(3);
        MobileAction.click(Locators.country_Options, "county selector");
        MobileAction.waitSec(2);
        MobileAction.scrollToElement("Argentina",false);
        MobileAction.waitSec(3);
        MobileAction.click(Locators.country_Name, "country name");
        MobileAction.waitSec(2);
        MobileAction.click(Locators.radio_Female, "female");
        MobileAction.click(Locators.btn_LetsShop, "lets shop");
        MobileAction.waitSec(3);
    }

        @When("Add item to the cart")
        public void Add_item_to_the_cart() throws IOException {


            MobileAction.scrollToElement("Air Jordan 4 Retro",false);
            MobileAction.click(Locators.Add_to_Cart);
            MobileAction.waitSec(3);
            MobileAction.click(Locators.button_Cart);
        }

        @Then("Visit the website")
                public void Visit_the_website() throws IOException {
            MobileAction.waitSec(2);
            MobileAction.click(Locators.visit_Website);


            Set<String> contexts = ((AndroidDriver) MobileDriverManager.getAppiumDriver()).getContextHandles();
            ((AndroidDriver) MobileDriverManager.getAppiumDriver()).context("WEBVIEW_com.androidsample.generalstore");
            MobileAction.typeText(Locators.Google_search, "GeminiSolutions");
            MobileDriverManager.getAppiumDriver().findElement(By.name("q")).sendKeys(Keys.ENTER);

            MobileAction.waitSec(3);
            MobileAction.click(Locators.google_First_link);
            MobileAction.navigateBack(false);
            MobileAction.waitSec(3);
            MobileAction.navigateForward(false);
            MobileAction.waitSec(3);


            MobileAction.navigateToUrl("https://github.com/", false);
            MobileAction.refresh(false);
            MobileAction.waitSec(3);


            ((AndroidDriver) MobileDriverManager.getAppiumDriver()).pressKey(new KeyEvent(AndroidKey.BACK));
            ((AndroidDriver) MobileDriverManager.getAppiumDriver()).context("NATIVE_APP");


        }

        @Given("Login to the app username {string}")
    public void Login_to_the_app(String username){
            MobileAction.typeText(Locators.input_Name,username);
            MobileAction.waitSec(2);
            MobileAction.click(Locators.radio_Female);
            MobileAction.click(Locators.btn_LetsShop);
            MobileAction.waitSec(3);
        }


}


