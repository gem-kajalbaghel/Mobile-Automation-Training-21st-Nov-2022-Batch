package com.gemini.generic.steps;

import com.gemini.generic.MobileAction;
import com.gemini.generic.locator.Locators;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.pages.ListOfWebElementFacades;
import org.openqa.selenium.WebElement;

import java.util.List;


public class StepDefinition {

    public static String PRODUCT_NAME = null;

    @Given("fill the information form with {string} {string} {string}")
    public void fillTheInformationFormWith(String country, String name, String gender) {
        MobileAction.click(Locators.select_country, "Country Dropdown");
        MobileAction.scrollToElement(country, false);

        for (WebElement element : MobileAction.getElements(Locators.option_country)) {
            if (element.getText().equals(country)) {
                MobileAction.click(element, country);
                break;
            }
        }

        MobileAction.typeText(Locators.input_name, name, "name");
        if (gender.equalsIgnoreCase("Male")) {
            MobileAction.click(Locators.radio_male, "male");
        } else if (gender.equalsIgnoreCase("Female")) {
            MobileAction.click(Locators.radio_female, "female");
        }
    }

    @When("click on Lets Shop button")
    public void clickOnLetsShopButton() {
        MobileAction.click(Locators.button_letsShop, "Let's Shop");
    }

    @And("add item {string} to the cart")
    public void addItemToTheCart(String itemName) {
        try {
            boolean flag = false;
            for (int i = 0; i < 10; i++) {
                List<WebElement> items = MobileAction.getElements(Locators.card_item_name);
                int index = 0;
                for (int j = 0; j < 2; j++) {
                    if (items.get(j).getText().equals(itemName)) {
                        List<WebElement> buttons = MobileAction.getElements(Locators.button_item_cart);
                        MobileAction.click(buttons.get(index), "Add to Cart");
                        flag = true;
                        break;
                    }
                    index++;
                }
                if (flag) {
                    break;
                }
                MobileAction.swipeUp(Locators.scrollableArea_Item, false);
                Thread.sleep(1000);
                items.clear();
            }
            PRODUCT_NAME = itemName;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Then("click on cart button")
    public void clickOnCartButton() {
        MobileAction.click(Locators.button_cart, "cart");
    }

    @And("verify the selected product in cart")
    public void verifyTheSelectedProductInCart() {
        MobileAction.verifyEquals(Locators.label_cartItem_name, PRODUCT_NAME);
    }

    @And("long press on terms and condition link")
    public void longPressOnTermsAndConditionLink() {
        MobileAction.longPress(Locators.button_termsLink, true);
    }

    @And("verify the alert dialog box")
    public void verifyTheAlertDialogBox() {
        MobileAction.verifyEquals(Locators.title_alert, "Terms Of Conditions");
    }

    @And("close the alert dialog box")
    public void closeTheAlertDialogBox() {
        MobileAction.click(Locators.button_alertClose, "Alert Close");
    }


}
