package stepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import locators.Locators;
import net.serenitybdd.core.pages.ListOfWebElementFacades;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import static java.time.temporal.ChronoUnit.SECONDS;
import static org.junit.Assert.assertEquals;

public class TestSteps extends PageObject {

    @Given("enter the name as {string}")
    public void enterTheNameAs(String name) {
        setImplicitTimeout(20, SECONDS);
        typeInto(element(Locators.input_name), name);
    }

    @When("click on Lets Shop button")
    public void clickOnLetsShopButton() {
        clickOn(element(Locators.button_letsShop));
    }

    @And("select gender as {string}")
    public void selectGenderAs(String gender) {
        if (gender.equalsIgnoreCase("Male")) {
            clickOn(element(Locators.radio_male));
        } else if (gender.equalsIgnoreCase("Female")) {
            clickOn(element(Locators.radio_female));
        }
    }

    @Then("verify the items page")
    public void verifyTheItemsPage() {
        ListOfWebElementFacades items = $$(Locators.card_item_name);
        for(WebElementFacade item : items){
            System.out.println(item.getText());
        }
    }
}
