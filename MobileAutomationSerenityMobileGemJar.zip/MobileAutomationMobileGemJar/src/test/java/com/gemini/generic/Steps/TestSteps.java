package com.gemini.generic.Steps;

import com.gemini.generic.Locators.Locators;
import com.gemini.generic.MobileAction;
import io.appium.java_client.android.AndroidDriver;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;

public class TestSteps extends PageObject {
//    AndroidDriver driver =(AndroidDriver) ((WebDriverFacade) getDriver()).getProxiedDriver();

    @Given("Launch Application")
    public void launchApplication(){
        System.out.println("Application Launched Successfully");
    }

    @When("Mention all Details and Enter into Application")
    public void insertDetails(){
//        MobileAction.typeText(Locators.enterYourName,"Hello"); // MobileAction class only
        typeInto(MobileAction.getElement(Locators.enterYourName),"My_Name"); // Serenity and Mobile GemJar

        MobileAction.takeSnapShot();
//        MobileAction.click(Locators.letsShopButton); // MobileAction class only
        clickOn(MobileAction.getElement(Locators.letsShopButton)); // Serenity and Mobile GemJar

        System.out.println("Primary Details Entered");
//        MobileAction.waitUntilElementVisible();

    }

    @Then("Order First Item")
    public void orderFirstItem(){

//        MobileAction.click(Locators.addToCart_option); // MobileAction class only
        clickOn(MobileAction.getElement(Locators.addToCart_option)); // Serenity and Mobile GemJar
        MobileAction.takeSnapShot();

//        MobileAction.click(Locators.cartButton); // MobileAction class only
        clickOn(MobileAction.getElement(Locators.cartButton)); // Serenity and Mobile GemJar
        MobileAction.takeSnapShot();

//        MobileAction.click(Locators.sendEmailOnDiscounts_CheckBox); // MobileAction class only
        clickOn(MobileAction.getElement(Locators.sendEmailOnDiscounts_CheckBox)); // Serenity and Mobile GemJar
        MobileAction.takeSnapShot();

//        MobileAction.click(Locators.letsProceedForPurchase); // MobileAction class only
        clickOn(MobileAction.getElement(Locators.letsProceedForPurchase)); // Serenity and Mobile GemJar
        MobileAction.takeSnapShot();

        System.out.println("Order Placed Successfully!!!");
    }
}
