package Uipage;

import com.google.common.collect.ImmutableMap;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;
import net.serenitybdd.core.pages.ListOfWebElementFacades;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.webdriver.WebDriverFacade;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;

import java.util.List;

import static io.appium.java_client.touch.WaitOptions.waitOptions;
import static java.time.Duration.ofMillis;
import static java.time.Duration.ofSeconds;
import static java.time.temporal.ChronoUnit.SECONDS;

public class DemoAppPage extends PageObject {
    public AndroidDriver getAndroidDriver() {
        return (AndroidDriver) ((WebDriverFacade) getDriver()).getProxiedDriver();
    }

    public void setImplicitWait(int seconds) {
        setImplicitTimeout(seconds, SECONDS);
    }

    public void doClick(By locator) {
        clickOn(element(locator));
    }

    public void doClick(WebElementFacade element) {
        clickOn(element);
    }

    public void doTypeText(By locator, String text) {
        typeInto(element(locator), text);
    }

    public ListOfWebElementFacades getElementFacadesList(By locator) {
        return $$(locator);
    }

    public List<WebElement> getElementsList(By locator) {
        return getAndroidDriver().findElements(locator);
    }

    public String getElementText(By locator) {
        return textOf(locator);
    }

    public void doLongPress(By locator) {
        LongPressOptions longPressOptions = new LongPressOptions();
        WebElement element = getAndroidDriver().findElement(locator);
        longPressOptions.withDuration(ofSeconds(2)).withElement(ElementOption.element(element));
        TouchAction action = new TouchAction((PerformsTouchActions) getAndroidDriver());
        action.longPress(longPressOptions).release().perform();
    }

    public void doSwipe(WebElement locator, String direction) {
        ((JavascriptExecutor) getAndroidDriver()).executeScript("mobile: swipeGesture", ImmutableMap.of(
                "elementId", ((RemoteWebElement) locator).getId(),
                "direction", direction,
                "percent", 0.75
        ));
    }

    public void doSwipe(By locator) { // locator - scrollable area
        WebElement ele = element(locator);
        int centerX = ele.getRect().x + (ele.getSize().width / 2);
        double startY = ele.getRect().y + (ele.getSize().height * 0.5);
        double endY = ele.getRect().y + (ele.getSize().height * 0.1);

        TouchAction swipe = new TouchAction((PerformsTouchActions) getAndroidDriver())
                .press(PointOption.point(centerX, (int) startY))
                .waitAction(waitOptions(ofMillis(800)))
                .moveTo(PointOption.point(centerX, (int) endY))
                .release()
                .perform();
    }

    public void doScrollToText(String text) {
        getAndroidDriver().findElement(AppiumBy.androidUIAutomator("new UiScrollable(" +
                "new UiSelector()).scrollIntoView(text(\"" + text + "\"));"));
    }
}
