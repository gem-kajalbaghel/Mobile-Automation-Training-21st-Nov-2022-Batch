package steps;

import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.pages.ListOfWebElementFacades;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.Step;
import uiPage.AppPage;
import uiPage.Locators;

import static org.junit.Assert.assertEquals;

public class PageSteps {

    AppPage appPage;

    public void setTimeout() {
        appPage.setImplicitWait(20);
    }

    @Step("Select Views")
    public void selectViews() {
        appPage.doClick(Locators.option_views);
    }

    @Step("Select Popup Menu")
    public void selectPopupMenu() {
        appPage.doScrollToText("Popup Menu");
        ListOfWebElementFacades elements = appPage.getElementFacadesList(Locators.options_popupMenu);
        for (WebElementFacade element : elements) {
            if (appPage.getElementText(element).equals("Popup Menu")) {
                appPage.doClick(element);
                break;
            }
        }
    }

    @Step("Make a Popup")
    public void makeAPopup() {
        appPage.doClick(Locators.button_makePopup);
    }

    @Step("Select Add Option")
    public void selectAdd() {
        appPage.doClick(Locators.item_add);
    }

    @Step("Verify Toast Message")
    public void verifyToastMessage() {
        assertEquals("Clicked popup menu item Add", appPage.getToastMessage(Locators.toast_message));
    }

    @Step("Select Drag and Drop Option")
    public void selectDragDrop() {
        appPage.doClick(Locators.option_dragDrop);
    }

    @Step("Perform Drag and Drop")
    public void performDragDrop() {
        appPage.doDragAndDrop(Locators.source_element, 818, 729);
    }

    @Step("Verify Dropped Message")
    public void verifyDropped() {
        assertEquals("Dropped!", appPage.getElementText(Locators.message_dropped));
    }


}
