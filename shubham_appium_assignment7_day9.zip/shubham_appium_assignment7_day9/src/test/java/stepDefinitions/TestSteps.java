package stepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import steps.PageSteps;

public class TestSteps {
    @Steps
    PageSteps pageSteps;

    @Given("make a popup")
    public void makeAPopup() {
        pageSteps.setTimeout();
        pageSteps.selectViews();
        pageSteps.selectPopupMenu();
        pageSteps.makeAPopup();
    }

    @When("click on Add Item")
    public void clickOnAddItem() {
        pageSteps.selectAdd();
    }

    @Then("then verify toast message")
    public void thenVerifyToastMessage() {
        pageSteps.verifyToastMessage();
    }

    @Given("go to the drag and drop option")
    public void goToTheDragAndDropOption() {
        pageSteps.setTimeout();
        pageSteps.selectViews();
        pageSteps.selectDragDrop();
    }

    @When("drop a item to the target")
    public void dropAItemToTheTarget() {
        pageSteps.performDragDrop();
    }

    @Then("then verify dropped message")
    public void thenVerifyDroppedMessage() {
        pageSteps.verifyDropped();
    }

}
