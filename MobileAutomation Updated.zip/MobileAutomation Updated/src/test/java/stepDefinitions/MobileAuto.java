package stepDefinitions;

import Steps.DemoAppSteps;
import UIPage.Locators;
import com.google.common.collect.ImmutableMap;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java.hu.De;
import net.serenitybdd.screenplay.actions.Scroll;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.pages.PageObject;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebElement;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.List;

public class MobileAuto extends PageObject{

    @Managed(driver = "appium")
    WebDriver driver;
    @Steps
   DemoAppSteps demoappsteps;
    @Then("^Launch the Application$")
    public void MobileAutomationLaunch() throws MalformedURLException {
        //demoappsteps = new DemoAppSteps();
        demoappsteps.Launch();
    }
    @Then("^Check Alert message$")
    public void CheckAlert() throws InterruptedException {
        //demoappsteps = new DemoAppSteps();
        demoappsteps.Alert();
    }

    @Then("^Check for Long Press$")
    public void CheckLongPress() throws InterruptedException {
//        demoappsteps = new DemoAppSteps();
        demoappsteps.LongPress();
    }
    @Then("^Check for Scroll$")
    public void CheckScroll() throws InterruptedException {
        //demoappsteps = new DemoAppSteps();
        demoappsteps.Scroll();
    }
    @Then("^Check for Swipe$")
    public void CheckSwipe() throws InterruptedException {
        //demoappsteps = new DemoAppSteps();
        demoappsteps.Swipe();
    }
    @Then("^Check for dropdown$")
    public void CheckDropDown() throws InterruptedException {
        //demoappsteps = new DemoAppSteps();
        demoappsteps.DropDown();
    }
    @Then("Check for toast message")
    public void CheckToastMessage() throws InterruptedException {
        //demoappsteps = new DemoAppSteps();
        demoappsteps.ToastMessage();
    }
    @Then("Check for drag and drop")
    public void CheckDragDrop() throws InterruptedException {
        //demoappsteps = new DemoAppSteps();
        demoappsteps.DragDrop();
    }}