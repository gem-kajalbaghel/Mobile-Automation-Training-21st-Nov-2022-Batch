package UIPage;

import com.google.common.collect.ImmutableMap;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.webdriver.WebDriverFacade;
import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebElement;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.List;

public class DemoApp extends PageObject {
    AndroidDriver driver =(AndroidDriver) ((WebDriverFacade) getDriver()).getProxiedDriver();
        public void selectPreference(){
            clickOn(element(Locators.option_preference));
        }
        public void selectPreferenceDependencies(){
            $(Locators.optionPreference_dependencies).click();
        }
        public void selectWifiCheckBox(){
            $(Locators.checkbox_wifi).click();
        }
        public void selectWifiSettings(){
            clickOn(element(Locators.option_wifiSettings)); }
        public void enterWifiName(String wifiName){

            typeInto(element(Locators.input_wifiName),wifiName);
        }
        public void clickOkButton(){
            clickOn(element(Locators.alert_OkButton));

            System.out.println("Done");
        }
        public void MobileAutoLaunch() throws MalformedURLException {
            try {
                Thread.sleep(2000);
            }
            catch (InterruptedException E){
                System.out.println("Error message");
                E.printStackTrace();
            }
            System.out.println("Application Launched successfully");
//            DesiredCapabilities capability = new DesiredCapabilities();
//            capability.setCapability("deviceName","Pixel3");
//            capability.setCapability("udid", "emulator-5554");
//            capability.setCapability("platformName", "Android");
//            capability.setCapability("app","C:\\Users\\an.jain2\\Desktop\\Mobile-Automation-Training\\MobileAutomation\\app\\ApiDemos-debug.apk");
//            driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"),capability);
        try {
            Thread.sleep(2000);
            }
        catch (InterruptedException E){
                System.out.println("Error message");
                E.printStackTrace();
        }}
        @When("^Check for Application$")
        public void applicationlaunched() throws InterruptedException {

            System.out.println("Launching API Demos application through Intellij");
            Thread.sleep(2000);
        }

//    @Then("Click on number")
//    public void clickOnNumber(String numStr) throws InterruptedException {
//        driver.findElement(Locators.digit).click();
//        driver.findElement(Locators.type).sendKeys("1234");
//        Thread.sleep(2000);
//    }
        public void checkAlertMessage() {
            driver.findElement(Locators.app).click();
            driver.findElement(Locators.alertDialogue).click();
            driver.findElement(Locators.dialogue).click();
            driver.findElement(Locators.alertPopUp).click();
            try {
                Thread.sleep(2000);
            }
            catch (InterruptedException E){
                System.out.println("Error message");
                E.printStackTrace();
            }
        }
        public void longPressTest() throws InterruptedException {
            driver.findElement(Locators.views).click();
            driver.findElement(Locators.expandableList).click();
            driver.findElement(Locators.customAdapter).click();

            LongPressOptions longPressOptions = new LongPressOptions();
            WebElement element = driver.findElement(Locators.peopleName);
            longPressOptions.withDuration(Duration.ofSeconds(2)).withElement(ElementOption.element(element));
            TouchAction action = new TouchAction<>((PerformsTouchActions)driver);
            action.longPress(longPressOptions).release().perform();

            Thread.sleep(2000);
        }
        public void scroll() throws InterruptedException {
            driver.findElement(Locators.views).click();
            driver.findElement((AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector().scrollable(true)).scrollIntoView"+"(text(\"WebView\"));")));
            Thread.sleep(2000);
        }
        public void swipe() throws InterruptedException{
            driver.findElement(Locators.views).click();
            driver.findElement(AppiumBy.accessibilityId("Gallery")).click();
            driver.findElement(AppiumBy.accessibilityId("1. Photos")).click();

            WebElement image = driver.findElement(AppiumBy.xpath("(//android.widget.ImageView)[1])"));
            ((JavascriptExecutor) driver).executeScript("mobile: swipeGesture", ImmutableMap.of(
                    "elementId",((RemoteWebElement) image).getId(),
                    "direction","left",
                    "percent","0.75"
            ));

            Thread.sleep(2000);
        }
        public void dropdown() throws InterruptedException {
            driver.findElement(Locators.views).click();
            driver.findElement(AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView" + "(text(\"Popup Menu\"));"));
            driver.findElement(AppiumBy.accessibilityId("Popup Menu")).click();
            driver.findElement(AppiumBy.accessibilityId("Make a Popup!")).click();

            List<WebElement> dropdown = driver.findElements(AppiumBy.xpath("//android.widget.LinearLayout//android.widget.TextView"));

            for (WebElement element : dropdown) {
                System.out.println(element.getText());
                if (element.getText().equals("Search")) {
                    element.click();
                }
                Thread.sleep(2000);
                break;
            }}
        public void ToastMsg(){
            driver.findElement(Locators.views).click();
            driver.findElement(AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView" + "(text(\"Popup Menu\"));"));
            driver.findElement(AppiumBy.accessibilityId("Popup Menu")).click();
            driver.findElement(AppiumBy.accessibilityId("Make a Popup!")).click();
            List<WebElement> eles = driver.findElements(AppiumBy.xpath("//android.widget.LinearLayout//android.widget.TextView"));
            clickOn(element(eles.get(0)));

            String message = driver.findElement(Locators.ToastMessage).getAttribute("name");
            Assert.assertEquals("Clicked popup menu item Search", message);
        }
        @Then("Check for drag and drop")
        public void DragDropVerify(){
            driver.findElement(Locators.views).click();
            clickOn(driver.findElement(Locators.DragDrop));
            WebElement sourceDrag = driver.findElement(Locators.sourceDrag);

            ((JavascriptExecutor)driver).executeScript("mobile: dragGesture",ImmutableMap.of(
                    "elementId",((RemoteWebElement)sourceDrag).getId(),
                    "endX",500,
                    "endY",500
            ));
            String result = driver.findElement(Locators.dragResult).getText();
            System.out.println(result);
            Assert.assertEquals("Dropped!",result);
        }
    }