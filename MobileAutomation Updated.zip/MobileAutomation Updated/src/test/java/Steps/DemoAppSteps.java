package Steps;

import UIPage.DemoApp;
import net.thucydides.core.annotations.Step;
import io.cucumber.java.en.Given;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.pages.PageObject;

import java.net.MalformedURLException;

public class DemoAppSteps {
    DemoApp demoAppPageSteps;
    @Step("Launch the application")
    public void Launch() throws MalformedURLException {
        demoAppPageSteps.MobileAutoLaunch();
    }

    @Step("^Click on Preference")
    public void preference(){
        demoAppPageSteps.selectPreference();
        demoAppPageSteps.selectPreferenceDependencies();
        demoAppPageSteps.selectWifiCheckBox();
        demoAppPageSteps.selectWifiSettings();
        demoAppPageSteps.enterWifiName("Ananya001");
        demoAppPageSteps.clickOkButton();
    }

    @Step("Alert")
    public void Alert() throws InterruptedException {
        demoAppPageSteps.checkAlertMessage();
    }
    @Step("Long Press")
    public void LongPress() throws InterruptedException {
        demoAppPageSteps.longPressTest();
    }
    @Step("Scroll")
    public void Scroll() throws InterruptedException {
        demoAppPageSteps.scroll();
    }
    @Step("Swipe")
    public void Swipe() throws InterruptedException {
        demoAppPageSteps.swipe();
    }
    @Step("DropDown")
    public void DropDown() throws InterruptedException {
        demoAppPageSteps.dropdown();
    }
    @Step("Toast Message")
    public void ToastMessage() throws InterruptedException {
        demoAppPageSteps.ToastMsg();
    }
    @Step("Drag Drop")
    public void DragDrop() throws InterruptedException {
        demoAppPageSteps.DragDropVerify();
    }
}

