package steps;

import io.appium.java_client.AppiumBy;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;

public class Apksteps extends PageObject {

    @Step
    public void click_on_signup(){
//        driver.findElement(AppiumBy.id("io.perfecto.expense.tracker:id/login_signup_btn")).click();
    clickOn(element(AppiumBy.id("io.perfecto.expense.tracker:id/login_signup_btn")));
//    typeInto(    , "   ");
    }


}
