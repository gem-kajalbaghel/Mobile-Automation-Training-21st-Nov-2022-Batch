package com.gemini.generic.steps;

import com.gemini.generic.MobileAction;
import com.gemini.generic.MobileDriverManager;
import com.gemini.generic.locator.Locators;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import java.util.List;


public class StepDefinition extends PageObject {

    public static String PRODUCT_NAME = null;

    public WebElement getElement(By locator) {
        return MobileAction.getElement(locator);
    }

    @Given("fill the information form with {string} {string} {string}")
    public void fillTheInformationFormWith(String country, String name, String gender) {
        MobileAction.setImplicitTimeOut(20);
        clickOn(getElement(Locators.select_country));
        MobileAction.scrollToElement(country, false);

        for (WebElement element : MobileAction.getElements(Locators.option_country)) {
            if (element.getText().equals(country)) {
                MobileAction.click(element, country);
                break;
            }
        }
        typeInto(getElement(Locators.input_name), name);
        if (gender.equalsIgnoreCase("Male")) {
            clickOn(getElement(Locators.radio_male));
        } else if (gender.equalsIgnoreCase("Female")) {
            clickOn(getElement(Locators.radio_female));
        }
    }

    @When("click on Lets Shop button")
    public void clickOnLetsShopButton() {
        clickOn(getElement(Locators.button_letsShop));
    }

    @And("add item {string} to the cart")
    public void addItemToTheCart(String itemName) {
        try {
            boolean flag = false;
            for (int i = 0; i < 10; i++) {
                List<WebElement> items = MobileAction.getElements(Locators.card_item_name);
                int index = 0;
                for (int j = 0; j < 2; j++) {
                    if (items.get(j).getText().equals(itemName)) {
                        List<WebElement> buttons = MobileAction.getElements(Locators.button_item_cart);
//                        MobileAction.click(buttons.get(index), "Add to Cart");
                        clickOn(buttons.get(index));
                        flag = true;
                        break;
                    }
                    index++;
                }
                if (flag) {
                    break;
                }
                MobileAction.swipeUp(Locators.scrollableArea_Item, false);
                Thread.sleep(1000);
                items.clear();
            }
            PRODUCT_NAME = itemName;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Then("click on cart button")
    public void clickOnCartButton() {
        clickOn(getElement(Locators.button_cart));
    }

    @And("verify the selected product in cart")
    public void verifyTheSelectedProductInCart() {
        MobileAction.waitUntilElementVisible(Locators.label_cartItem_name, 10);
        MobileAction.verifyEquals(Locators.label_cartItem_name, PRODUCT_NAME);
    }

    @And("long press on terms and condition link")
    public void longPressOnTermsAndConditionLink() {
        MobileAction.longPress(Locators.button_termsLink, false);
    }

    @And("verify the alert dialog box")
    public void verifyTheAlertDialogBox() {
        MobileAction.verifyEquals(textOf(Locators.title_alert), "Terms Of Conditions");
    }

    @And("close the alert dialog box")
    public void closeTheAlertDialogBox() {
        clickOn(getElement(Locators.button_alertClose));
    }


    @And("perform browser launch")
    public void performBrowserLaunch() {
        clickOn(getElement(Locators.visit_website));
        MobileAction.waitSec(5);
        MobileAction.switchToWebView();
        typeInto(getElement(Locators.search), "testingwithsk.in");
        MobileAction.waitSec(1);
        getElement(Locators.search).sendKeys(Keys.ENTER);
        MobileAction.waitUntilElementVisible(Locators.first_link, 10);
        clickOn(getElement(Locators.first_link));
        MobileAction.waitSec(5);
    }
}
