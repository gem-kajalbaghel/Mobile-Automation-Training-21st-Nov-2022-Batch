package com.gemini.generic.Steps;

import com.gemini.generic.Locators.Locators;
import com.gemini.generic.MobileAction;
import com.gemini.generic.MobileDriverManager;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import javax.naming.Context;
import java.util.Locale;
import java.util.Set;

public class TestSteps extends PageObject {

    @Step
    @Given("Launch the Application")
    public void launchApp(){

        System.out.println("Application Launched Successfully");

    }

    @When("Enter you Details")
    public void TypeInDetails(){

//        MobileAction.typeText(Locators.name, nameEntered, "Name");
        typeInto(MobileAction.getElement(Locators.name),"Karan");

        MobileAction.waitSec(3);
        MobileAction.click(Locators.countryOtions, "Country element");
        MobileAction.waitSec(2);
         MobileAction.scrollToElement("Canada",false); //don't need to add in reporting

        MobileAction.waitSec(3);

        MobileAction.click(Locators.country_Name, "Country names");
        MobileAction.waitSec(2);
        MobileAction.click(Locators.radio_Male, "Male radio button");
//        MobileAction.click(Locators.LetsShop, "lets Shop");

        clickOn(MobileAction.getElement(Locators.LetsShop));
        MobileAction.waitSec(3);
    }

    @Then("Order your Item")
    public void orderItem(){
        MobileAction.scrollToElement("Air Jordan 4 Retro",false); //this won't come in reporting
        MobileAction.click(Locators.Add_to_Cart);

        MobileAction.waitSec(3);
        MobileAction.click(Locators.btn);

    }

    @Then("Visit Website")
    public void visitWebsite() {
        MobileAction.waitSec(2);
        MobileAction.click(Locators.visit_Website);
        MobileAction.waitSec(3);
        MobileAction.switchToWebView();
        //we need to switch from native view to web view

    }


}
