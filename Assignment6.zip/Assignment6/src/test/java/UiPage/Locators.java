package UiPage;

import io.appium.java_client.AppiumBy;
import org.openqa.selenium.By;

public class Locators {
    public static By option_views = AppiumBy.accessibilityId("Views");
    public static By options_popupMenu = AppiumBy.xpath("//android.widget.ListView/" +
            "android.widget.TextView");
    public static By button_makePopup = AppiumBy.accessibilityId("Make a Popup!");
    public static By item_add = AppiumBy.xpath("(//android.widget.TextView[@resource-id=" +
            "'android:id/title'])[2]");
    public static By toast_message = AppiumBy.xpath("(//android.widget.Toast)[1]");


    public static By option_dragDrop = AppiumBy.accessibilityId("Drag and Drop");
    public static By source_element = AppiumBy.id("io.appium.android.apis:id/drag_dot_1");
    public static By message_dropped = AppiumBy.id("io.appium.android.apis:id/drag_result_text");
}
