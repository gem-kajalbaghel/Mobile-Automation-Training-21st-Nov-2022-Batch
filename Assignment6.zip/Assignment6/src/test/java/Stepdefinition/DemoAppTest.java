package Stepdefinition;

import Steps.DemoAppSteps;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.net.MalformedURLException;

public class DemoAppTest {

    DemoAppSteps demosteps;

    @Given("make a popup")
    public void makeAPopup() {
        demosteps.setTimeout();
        demosteps.selectViews();
        demosteps.selectPopupMenu();
        demosteps.makeAPopup();
    }

    @When("click on Add Item")
    public void clickOnAddItem() {
        demosteps.selectAdd();
    }

    @Then("then verify toast message")
    public void thenVerifyToastMessage() {
        demosteps.verifyToastMessage();
    }

    @Given("go to the drag and drop option")
    public void goToTheDragAndDropOption() {
        demosteps.setTimeout();
        demosteps.selectViews();
        demosteps.selectDragDrop();
    }

    @When("drop a item to the target")
    public void dropAItemToTheTarget() {
        demosteps.performDragDrop();
    }

    @Then("then verify dropped message")
    public void thenVerifyDroppedMessage() {
        demosteps.verifyDropped();
    }

}
