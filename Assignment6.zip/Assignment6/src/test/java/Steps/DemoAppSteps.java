package Steps;

import UiPage.DemoAppPage;
import UiPage.Locators;
import net.serenitybdd.core.pages.ListOfWebElementFacades;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;

import java.net.MalformedURLException;

import static org.junit.Assert.assertEquals;

public class DemoAppSteps {

    @Steps
    DemoAppPage demopage;
    public void setTimeout() {
        demopage.setImplicitWait(20);
    }

    @Step("Select Views")
    public void selectViews() {
        demopage.doClick(Locators.option_views);
    }

    @Step("Select Popup Menu")
    public void selectPopupMenu() {
        demopage.doScrollToText("Popup Menu");
        ListOfWebElementFacades elements = demopage.getElementFacadesList(Locators.options_popupMenu);
        for (WebElementFacade element : elements) {
            if (demopage.getElementText(element).equals("Popup Menu")) {
                demopage.doClick(element);
                break;
            }
        }
    }

    @Step("Make a Popup")
    public void makeAPopup() {
        demopage.doClick(Locators.button_makePopup);
    }

    @Step("Select Add Option")
    public void selectAdd() {
        demopage.doClick(Locators.item_add);
    }

    @Step("Verify Toast Message")
    public void verifyToastMessage() {
        assertEquals("Clicked popup menu item Add", demopage.getToastMessage(Locators.toast_message));
    }

    @Step("Select Drag and Drop Option")
    public void selectDragDrop() {
        demopage.doClick(Locators.option_dragDrop);
    }

    @Step("Perform Drag and Drop")
    public void performDragDrop() {
        demopage.doDragAndDrop(Locators.source_element, 818, 729);
    }

    @Step("Verify Dropped Message")
    public void verifyDropped() {
        assertEquals("Dropped!", demopage.getElementText(Locators.message_dropped));
    }





}
