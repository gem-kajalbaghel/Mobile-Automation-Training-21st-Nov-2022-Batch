package stepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import steps.PageSteps;

public class TestSteps {
    @Steps
    PageSteps pageSteps;

    @Given("fill the information form with {string} {string} {string}")
    public void fillTheInformationFormWith(String country, String name, String gender) {
        pageSteps.setTimeout();
        pageSteps.selectCountry(country);
        pageSteps.enterName(name);
        pageSteps.selectGender(gender);
    }

    @When("click on Lets Shop button")
    public void clickOnLetsShopButton() {
        pageSteps.clickOnLetsShop();
    }

    @And("add item {string} to the cart")
    public void addItemToTheCart(String itemName) {
        pageSteps.selectItemAndAddToCart(itemName);
    }

    @Then("click on cart button")
    public void clickOnCartButton() {
        pageSteps.clickOnCart();
    }

    @And("verify the selected product in cart")
    public void verifyTheSelectedProductInCart() {
        pageSteps.verifyItemOnCart();
    }

    @And("long press on terms and condition link")
    public void longPressOnTermsAndConditionLink() {
        pageSteps.longPressOnTerms();
    }

    @And("verify the alert dialog box")
    public void verifyTheAlertDialogBox() {
        pageSteps.verifyAlertTitle();
    }

    @And("close the alert dialog box")
    public void closeTheAlertDialogBox() {
        pageSteps.closeAlert();
    }


}
