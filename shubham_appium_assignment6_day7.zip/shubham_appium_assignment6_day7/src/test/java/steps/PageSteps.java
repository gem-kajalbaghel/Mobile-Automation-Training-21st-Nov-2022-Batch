package steps;

import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.pages.ListOfWebElementFacades;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.Step;
import org.openqa.selenium.WebElement;
import uiPage.AppPage;
import uiPage.Locators;

import java.util.List;

import static org.junit.Assert.assertEquals;

public class PageSteps {

    AppPage appPage;

    public void setTimeout() {
        appPage.setImplicitWait(20);
    }

    @Step("Select Country")
    public void selectCountry(String country) {
        appPage.doClick(Locators.select_country);

        appPage.doScrollToText(country);

        for (WebElementFacade element : appPage.getElementFacadesList(Locators.option_country)) {
            if (element.getText().equals(country)) {
                appPage.doClick(element);
                break;
            }
        }
    }

    @Step("Enter Name")
    public void enterName(String name) {
        appPage.doTypeText(Locators.input_name, name);
    }

    @Step("Select Gender")
    public void selectGender(String gender) {
        if (gender.equalsIgnoreCase("Male")) {
            appPage.doClick(Locators.radio_male);
        } else if (gender.equalsIgnoreCase("Female")) {
            appPage.doClick(Locators.radio_female);
        }
    }

    @Step("Click ok lets shop button")
    public void clickOnLetsShop() {
        appPage.doClick(Locators.button_letsShop);
    }

    @Step("Add an item to the cart")
    public void selectItemAndAddToCart(String itemName) {
        try {
            Serenity.setSessionVariable("ItemName").to(itemName);
            boolean flag = false;
            for (int i = 0; i < 10; i++) {
                ListOfWebElementFacades items = appPage.getElementFacadesList(Locators.card_item_name);
                int index = 0;
                for (int j = 0; j < 2; j++) {
                    if (items.get(j).getText().equals(itemName)) {
                        ListOfWebElementFacades buttons =
                                appPage.getElementFacadesList(Locators.button_item_cart);
                        appPage.doClick(buttons.get(index));
                        flag = true;
                        break;
                    }
                    index++;
                }
                if (flag) {
                    break;
                }
                appPage.doSwipe(Locators.scrollableArea_Item);
                Thread.sleep(1000);
                items.clear();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Step("Click on cart button")
    public void clickOnCart() {
        appPage.doClick(Locators.button_cart);
    }

    @Step("Verify the item name on Cart Page")
    public void verifyItemOnCart() {
        String expected = Serenity.sessionVariableCalled("ItemName");
        String actual = appPage.getElementText(Locators.label_cartItem_name);
        assertEquals(expected, actual);
    }

    @Step("Long Press on Terms and Conditions")
    public void longPressOnTerms() {
        appPage.doLongPress(Locators.button_termsLink);
    }

    @Step("Verify Alert Dialog Title")
    public void verifyAlertTitle() {
        String title = appPage.getElementText(Locators.title_alert);
        assertEquals("Terms Of Conditions", title);
    }

    @Step("Close the Alert Dialog")
    public void closeAlert() {
        appPage.doClick(Locators.button_alertClose);
    }

}
