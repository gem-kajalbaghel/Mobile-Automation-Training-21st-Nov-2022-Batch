package uiPage;

import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.offset.ElementOption;
import net.serenitybdd.core.pages.ListOfWebElementFacades;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.webdriver.WebDriverFacade;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import static java.time.Duration.ofSeconds;
import static java.time.temporal.ChronoUnit.SECONDS;


public class AppPage extends PageObject {

    public AndroidDriver getAndroidDriver(){
        return (AndroidDriver) ((WebDriverFacade) getDriver()).getProxiedDriver();
    }

    public void setImplicitWait(int seconds) {
        setImplicitTimeout(seconds, SECONDS);
    }

    public void doClick(By locator) {
        clickOn(element(locator));
    }

    public void doClick(WebElementFacade element) {
        clickOn(element);
    }

    public void doTypeText(By locator, String text) {
        typeInto(element(locator), text);
    }

    public ListOfWebElementFacades getElementsList(By locator) {
        return $$(locator);
    }

    public String getElementText(By locator) {
        return textOf(locator);
    }

    public void doLongPress(By locator) {
        LongPressOptions longPressOptions = new LongPressOptions();
        WebElement element = getAndroidDriver().findElement(locator);
        longPressOptions.withDuration(ofSeconds(2)).withElement(ElementOption.element(element));
        TouchAction action = new TouchAction((PerformsTouchActions) getAndroidDriver());
        action.longPress(longPressOptions).release().perform();
    }
}
